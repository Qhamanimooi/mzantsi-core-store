# Mzantsi Core Store — GitHub Pages Edition

This is a ready-to-upload static site for GitHub Pages.
Files included: index.html, products.html, about.html, /products/*.html, /css, /js, /images (hotlinks).

## How to publish on GitHub Pages
1. Create a new repository on GitHub (e.g., `mzantsi-core-store`).
2. Upload all files from this folder to the repository root.
3. In the repo go to **Settings → Pages**, set **Branch** to `main` (or `master`) and folder to `/ (root)` and Save.
4. Wait ~1 minute and your site will be live at: `https://yourusername.github.io/repo-name`

## Notes
- Images are hotlinked from Unsplash (royalty-free) — you can replace them in /images with your own files if desired.
- PayPal Add-to-Cart forms post to PayPal with the business email `Qhamanimoyi@gmail.com` and currency set to ZAR.
- For best results enable HTTPS on your GitHub Pages site (GitHub manages this automatically).

Enjoy!
